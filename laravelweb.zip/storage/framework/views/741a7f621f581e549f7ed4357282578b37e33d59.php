<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <h1>Mail được gửi từ <?php echo e($name); ?></h1>
    <h2>ND: <?php echo e($body); ?></h2>
</body>
</html><?php /**PATH C:\xampp\htdocs\laravelweb\resources\views/pages/sendmail.blade.php ENDPATH**/ ?>