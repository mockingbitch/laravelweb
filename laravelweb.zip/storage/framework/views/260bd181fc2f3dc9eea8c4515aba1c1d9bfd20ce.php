
<?php $__env->startSection('content'); ?>
    <style type="text/css">
        .cart-header {
            font-weight: bold;
            font-size: 1.25em;
            color: #333;
        }

        .cart-column {
            display: flex;
            align-items: center;
            border-bottom: 1px solid black;
            margin-right: 1.5em;
            padding-bottom: 10px;
            margin-top: 10px;
        }

        .cart-row {
            display: flex;
        }

        .cart-item {
            width: 45%;
        }

        .cart-price {
            width: 20%;
            font-size: 1.2em;
            color: #333;
        }

        .cart-quantity {
            width: 35%;
        }

        .cart-item-title {
            color: #333;
            margin-left: .5em;
            font-size: 1.2em;
        }

        .cart-item-image {
            width: 75px;
            height: auto;
            border-radius: 10px;
        }

        .btn-danger {
            color: white;
            background-color: #EB5757;
            border: none;
            border-radius: .3em;
            font-weight: bold;
        }

        .btn-danger:hover {
            background-color: #CC4C4C;
        }

        .cart-quantity-input {
            height: 34px;
            width: 50px;
            border-radius: 5px;
            border: 1px solid #56CCF2;
            background-color: #eee;
            color: #333;
            padding: 0;
            text-align: center;
            font-size: 1.2em;
            margin-right: 25px;
        }

        .cart-row:last-child {
            border-bottom: 1px solid black;
        }

        .cart-row:last-child .cart-column {
            border: none;
        }

        .cart-total {
            text-align: end;
            margin-top: 10px;
            margin-right: 10px;
        }

        .cart-total-title {
            font-weight: bold;
            font-size: 1.5em;
            color: black;
            margin-right: 20px;
        }

        .cart-total-price {
            color: #333;
            font-size: 1.1em;
        }

    </style>
    
    <?php if(session()->has('message')): ?>
        <div class="alert alert-success">
            <?php echo e(session()->get('message')); ?>

        </div>
    <?php elseif(session()->has('error')): ?>
        <div class="alert alert-danger">
            <?php echo e(session()->get('error')); ?>

        </div>
    <?php endif; ?>
    <?php if(Session::get('cart')): ?>
    <form action="<?php echo e(URL('/update-cart')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div class="cart-row">
            <span class="cart-item cart-header cart-column">Sản Phẩm</span>
            <span class="cart-price cart-header cart-column">Giá</span>
            <span class="cart-quantity cart-header cart-column">Số Lượng</span>
            <span class="cart-price cart-header cart-column">Thành tiền</span>

        </div>
        <?php
            $total = 0;
        ?>
        <?php $__currentLoopData = Session::get('cart'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <?php
                $subtotal = $value['pr_price'] * $value['pr_qty'];
                $total += $subtotal;
            ?>

            <div class="cart-items">
                <div class="cart-row">
                    <div class="cart-item cart-column">
                        <img class="cart-item-image" src="<?php echo e(URL::to('public/uploads/product/' . $value['pr_img'])); ?>"
                            width="100" height="100">
                        <span class="cart-item-title"><?php echo e($value['pr_name']); ?></span>
                    </div>

                    <span class="cart-price cart-column"><?php echo e(number_format($value['pr_price'], 0, ',', '.')); ?>đ</span>

                    <div class="cart-quantity cart-column">
                        <input class="cart-quantity-input" value="<?php echo e($value['pr_qty']); ?>" name="cart_qty[<?php echo e($value['session_id']); ?>]" type="number" value="1" min="1">
                        <a href="<?php echo e(url('/delete-cart/' . $value['session_id'])); ?>"><i class="fa fa-trash"></i></a>
                    </div>
                    
                    <span class="cart-price cart-column"><?php echo e(number_format($subtotal, 0, ',', '.')); ?>đ</span>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <input type="submit" value="Cập nhật giỏ hàng" name="update_qty" class="btn btn-default btn-sm check_out">
        <div class="cart-total">
            
            <strong class="cart-total-title">Tổng Cộng:</strong>
            <span style="font-size:40px;font-weight:bold;"
                class="cart-total-price"><?php echo e(number_format($total, 0, ',', '.')); ?>đ</span>
        </div>
    </form>
   
    <form action="<?php echo e(url('/check-coupon')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="cp_value" >
        <input type="text" class="form-control" name="cp_code" placeholder="Nhập mã giảm giá">
        <input  type="submit" value="Tính mã giảm giá" class="btn btn-default check_out">
    </form>
    <?php else: ?>
    <hr>
    <h2 style="text-align:center">Vui lòng thêm sản phẩm vào giỏ hàng</h2>
    <hr>
    <?php endif; ?>
    

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravelweb\resources\views/pages/product/checkout.blade.php ENDPATH**/ ?>