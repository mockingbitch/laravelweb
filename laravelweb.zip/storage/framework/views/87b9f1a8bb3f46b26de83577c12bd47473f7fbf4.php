
<?php $__env->startSection('adminContent'); ?>
    <div class="row">
        <div class="col-lg-12">
            <section class="panel">
                <header class="panel-heading">
                   Cập nhật sản phẩm
                </header>
                <?php
                $message = Session::get('message');
                if ($message) {
                    echo '<span style="color:green;text-align:center">' . $message . '</span>';
                    Session::put('message', null);
                }
                ?>
                <div class="panel-body">
                    <?php $__currentLoopData = $editProduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="position-center">
                        <form role="form" action="<?php echo e(URL::to('/update-product/'.$value->pr_id)); ?>" method="post" enctype="multipart/form-data">
                            <?php echo e(csrf_field()); ?>

                            <div class="form-group">
                                <label for="exampleInputEmail1">Tên sản phẩm</label>
                                <input type="text" name="pr_name" class="form-control" id="exampleInputEmail1"
                                    value="<?php echo e($value->pr_name); ?>">
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Danh mục sản phẩm</label>
                                <select name="cate_id" class="form-control input-lg m-bot15">
                                   <?php $__currentLoopData = $cate_pr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $cate_value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                   <?php if($cate_value->cate_id == $value->cate_id): ?>
                                   <option selected value="<?php echo e($cate_value->cate_id); ?>"><?php echo e($cate_value->cate_name); ?></option>
                                   <?php endif; ?>
                                   <option value="<?php echo e($cate_value->cate_id); ?>"><?php echo e($cate_value->cate_name); ?></option>
                                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                   

                                </select>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Thương hiệu</label>
                                <select name="br_id" class="form-control input-lg m-bot15">
                                    <?php $__currentLoopData = $brand_pr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $br_value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($br_value->br_id == $value->br_id): ?>
                                   <option selected value="<?php echo e($br_value->br_id); ?>"><?php echo e($br_value->br_name); ?></option>
                                   <?php endif; ?>
                                   <option value="<?php echo e($br_value->br_id); ?>"><?php echo e($br_value->br_name); ?></option>
                                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </select>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputPassword1">Mô tả sản phẩm</label>
                                <textarea style="resize:none" rows="12" class="form-control" id="exampleInputPassword1"
                                    name="pr_des" placeholder="Mô tả danh mục"><?php echo e($value->pr_des); ?></textarea>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputPassword1">Thông tin chi tiết</label>
                                <textarea style="resize:none" rows="12" class="form-control" id="exampleInputPassword1"
                                    name="pr_content" placeholder="Mô tả danh mục"><?php echo e($value->pr_content); ?></textarea>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Giá sản phẩm</label>
                                <input type="text" name="pr_price" class="form-control" id="exampleInputEmail1"
                                    placeholder="Thêm tên danh mục" value="<?php echo e($value->pr_price); ?>">
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Hình ảnh sản phẩm</label>
                                <br/>
                                <img width= 200 src="<?php echo e(url('public/uploads/product')); ?>/<?php echo e($value->pr_img); ?>"  alt="">
                                <input type="file" name="pr_img" class="form-control" id="exampleInputEmail1"
                                    placeholder="Thêm tên danh mục">
                            </div>
                            <button name="updateProduct" type="submit" class="btn btn-info">Cập nhật</button>
                        </form>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </section>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravelweb\resources\views/admin/editProduct.blade.php ENDPATH**/ ?>