
<?php $__env->startSection('adminContent'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravelweb\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>