
<?php $__env->startSection('content'); ?>
    <div id="fh5co-content">
        <div class="container">
            <div class="row ">
                <div class="row animate-box col-md-9 col-padded-right">
                    <div class="col-md-12 col-md-offset-0 text-center fh5co-heading">
                            <h2><span>Search </span></h2>  
                    </div>
                    <div class="col-md-8">
                        <form action="<?php echo e(URL::to('/ket-qua-tim-kiem')); ?>" method="post" >
                            <?php echo e(csrf_field()); ?>

                            <div class="search_box pull-right">
                                <input type="text" name="keysearch" placeholder="Tìm kiếm sản phẩm"/>
                                <input type="submit" name="searchbutton" value="Search" class="btn btn-primary">
                            </div>
                        </form>
                    </div>
                </div>
                <aside id="sidebar">
                    <div class="col-md-3">
                        <div class="side animate-box">
                            <div class="col-md-12 col-md-offset-0 text-center fh5co-heading fh5co-heading-sidebar">
                                <h2><span>Category</span></h2>
                            </div>
                            <ul class="category">
                                <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value_cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><a href="<?php echo e(URL::to('/danh-muc-san-pham/' . $value_cate->cate_id)); ?>"><i
                                                class="icon-check"></i> &ensp; <?php echo e($value_cate->cate_name); ?></a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <div class="side animate-box">
                            <div class="col-md-12 col-md-offset-0 text-center fh5co-heading fh5co-heading-sidebar">
                                <h2><span>Brand</span></h2>
                            </div>
                            <ul class="category">
                                <?php $__currentLoopData = $brand; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value_brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><a href="<?php echo e(URL::to('/brand/' . $value_brand->br_id)); ?>"><i
                                                class="icon-check"></i> &ensp; <?php echo e($value_brand->br_name); ?></a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                        <div class="side animate-box">
                            <div class="col-md-12 col-md-offset-0 text-center fh5co-heading fh5co-heading-sidebar">
                                <h2><span>About Me</span></h2>
                            </div>
                            <div class="fh5co-staff">
                                <img src="images/user-2.jpg" alt="Free HTML5 Templates by FreeHTML5.co">
                                <h3>Jean Smith</h3>
                                <strong class="role">CEO, Founder</strong>
                                <p>Quos quia provident conse culpa facere ratione maxime commodi voluptates id repellat
                                    velit eaque aspernatur expedita.</p>
                                <ul class="fh5co-social-icons">
                                    <li><a href="#"><i class="icon-facebook"></i></a></li>
                                    <li><a href="#"><i class="icon-twitter"></i></a></li>
                                    <li><a href="#"><i class="icon-dribbble"></i></a></li>
                                    <li><a href="#"><i class="icon-github"></i></a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="side animate-box">
                            <div class="col-md-12 col-md-offset-0 text-center fh5co-heading fh5co-heading-sidebar">
                                <h2><span>Latest Posts</span></h2>
                            </div>
                            <div class="blog-entry">
                                <a href="#">
                                    <img src="images/blog-1.jpg" class="img-responsive" alt="">
                                    <div class="desc">
                                        <span class="date">Dec. 25, 2016</span>
                                        <h3>Most Beautiful Site in 2016</h3>
                                    </div>
                                </a>
                            </div>
                            <div class="blog-entry">
                                <a href="#">
                                    <img src="images/blog-2.jpg" class="img-responsive" alt="">
                                    <div class="desc">
                                        <span class="date">Dec. 25, 2016</span>
                                        <h3>Most Beautiful Site in 2016</h3>
                                    </div>
                                </a>
                            </div>
                            <div class="blog-entry">
                                <a href="#">
                                    <img src="images/blog-1.jpg" class="img-responsive" alt="">
                                    <div class="desc">
                                        <span class="date">Dec. 25, 2016</span>
                                        <h3>Most Beautiful Site in 2016</h3>
                                    </div>
                                </a>
                            </div>
                        </div>

                        
                    </div>
                </aside>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravelweb\resources\views/pages/product/search.blade.php ENDPATH**/ ?>